raise ImportError(
    "Vision features were moved to 'nano-wait-vision'. "
    "Install with: pip install nano-wait-vision"
)
