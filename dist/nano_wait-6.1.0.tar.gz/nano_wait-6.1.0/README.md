**Stop using `time.sleep()`. Use Intelligence.**

NanoWait is an adaptive execution engine that replaces static waits with an intelligent system that observes your hardware and learns over time.

---

## ⚡ Why NanoWait?

The traditional `time.sleep(2)` is dumb: it waits 2 seconds on both a supercomputer and a Raspberry Pi.

**NanoWait** observes your CPU, Memory, and Network usage to calculate the necessary real-time.

- **Faster:** On powerful machines, it cuts down on wait time.

- **Safer:** On overloaded machines, it increases resilience to prevent failures.

- **Self-Adjusting:** It learns from each execution and calibrates itself.

---

## 📦 Installation

```bash
pip install nano-wait
```

---

## 🚀 How to use (In 30 seconds)

### 1. The Intelligent Sleep Replacement
Instead of locking your script for a fixed time, let NanoWait decide the best timing based on the hardware.

``python
from nano_wait import wait

# Automatically adapts to PC and Network load
wait(2, smart=True)

```

### 2. Wait Conditions (Polling)
Wait until something happens (e.g., a button appears) without frying your processor.

```python
# Try at each adaptive interval until it succeeds or times out
wait(lambda: button.is_visible(), timeout=10)

```

### 3. Execution with Superpowers (Execute)
The ultimate way to run unstable functions (APIs, Web Automation).

``python
from nano_wait import execute

result = execute(my_unstable_function, timeout=10)

if result.success:

print(f"Success in {result.duration}s with {result.attempts} attempts!")
```

---

## 🛠 Ready-to-Use Profiles

Choose the ideal behavior for your scenario:

| Profile | Focus | When to use? |

| :--- | :--- | :--- |

| `ci` | ⚡ Speed ​​| GitHub Actions/GitLab Pipelines |

| Testing | ⚖️ Balance | Local QA Testing |

| RPA | 🛡️ Stability | Automation of slow or legacy websites |

---

## 🧠 How does it think?

NanoWait uses an **Opportunity Cost** formula:

`End Time = (Base Time / System Health) * Aggressiveness`

It monitors:

- 💻 **CPU & RAM:** If the PC is slow, it waits longer.

- 🌐 **Wi-Fi:** If the network is unstable, it increases tolerance.

- 📈 **History:** It saves a `~/.nano_wait_learning.json` file to become smarter with each round.

---

## 💡 Philosophy
> "Don't wait blindly. Execute intelligently."

--
Created for developers who hate unstable automations.