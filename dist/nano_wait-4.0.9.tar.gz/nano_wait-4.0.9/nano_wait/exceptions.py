class VisionTimeout(Exception):
    """Raised when a visual condition is not detected within the timeout."""
